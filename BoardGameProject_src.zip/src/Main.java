import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        ArrayList<String> rules = new ArrayList<>();
        rules.add("Zasada 1");
        rules.add("Zasada 2");

        EducationalGame game1 = new EducationalGame(
                "Matematyka",
                2,
                4,
                rules,
                "Matematyka"
        );

        StrategicGame game2 = new StrategicGame(
                "Catan",
                3,
                4,
                rules,
                90
        );

        System.out.println(game1);
        System.out.println(game2);

        game1.setSubject("Historia");
        game2.setDuration(120);

        System.out.println(game1.getSubject());
        System.out.println(game2.getDuration());

        System.out.println(game1.equals(game2));

        System.out.println(game1.hashCode());
        System.out.println(game2.hashCode());
    }
}
