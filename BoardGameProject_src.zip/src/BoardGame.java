import java.util.ArrayList;
import java.util.Objects;

public class BoardGame {

    private String gameName;
    private int minPlayers;
    private int maxPlayers;
    private ArrayList<String> rules;

    public BoardGame(String gameName, int minPlayers, int maxPlayers, ArrayList<String> rules) {
        this.gameName = gameName;
        this.minPlayers = minPlayers;
        this.maxPlayers = maxPlayers;
        this.rules = rules;
    }

    public String getGameName() {
        return gameName;
    }

    public void setGameName(String gameName) {
        this.gameName = gameName;
    }

    public int getMinPlayers() {
        return minPlayers;
    }

    public void setMinPlayers(int minPlayers) {
        this.minPlayers = minPlayers;
    }

    public int getMaxPlayers() {
        return maxPlayers;
    }

    public void setMaxPlayers(int maxPlayers) {
        this.maxPlayers = maxPlayers;
    }

    public ArrayList<String> getRules() {
        return rules;
    }

    public void setRules(ArrayList<String> rules) {
        this.rules = rules;
    }

    @Override
    public String toString() {
        return "BoardGame{" + gameName + ", " + minPlayers + ", " + maxPlayers + ", " + rules + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BoardGame)) return false;
        BoardGame that = (BoardGame) o;
        return minPlayers == that.minPlayers &&
                maxPlayers == that.maxPlayers &&
                Objects.equals(gameName, that.gameName) &&
                Objects.equals(rules, that.rules);
    }

    @Override
    public int hashCode() {
        return Objects.hash(gameName, minPlayers, maxPlayers, rules);
    }
}
