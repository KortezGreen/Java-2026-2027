import java.util.ArrayList;
import java.util.Objects;

public class EducationalGame extends BoardGame {

    private String subject;

    public EducationalGame(String gameName, int minPlayers, int maxPlayers,
                           ArrayList<String> rules, String subject) {
        super(gameName, minPlayers, maxPlayers, rules);
        this.subject = subject;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    @Override
    public String toString() {
        return super.toString() + ", subject=" + subject;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        EducationalGame that = (EducationalGame) o;
        return Objects.equals(subject, that.subject);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), subject);
    }
}
