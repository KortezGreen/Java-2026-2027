import java.util.ArrayList;
import java.util.Objects;

public class StrategicGame extends BoardGame {

    private int duration;

    public StrategicGame(String gameName, int minPlayers, int maxPlayers,
                         ArrayList<String> rules, int duration) {
        super(gameName, minPlayers, maxPlayers, rules);
        this.duration = duration;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    @Override
    public String toString() {
        return super.toString() + ", duration=" + duration;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        StrategicGame that = (StrategicGame) o;
        return duration == that.duration;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), duration);
    }
}
