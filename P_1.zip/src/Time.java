public class Time {
    int hours;
    int minutes;

    public Time(int hours, int minutes) {
        this.hours = hours;
        this.minutes = minutes;
    }

    public void addTime(Time otherTime){
        int minuty = this.minutes + otherTime.minutes;
        int plusH = minuty/60;

        this.minutes = minuty%60;
        this.hours = (this.hours+plusH+otherTime.hours)%24;
    }
}
