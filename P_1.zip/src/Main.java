public class Main {

    public static void main(String[] args) {
        //zad 1
        //Dog pies = new Dog("Labrador", "Czusia", 3);
        //pies.bark();

        //zad 2
/*      Car auto = new Car("Opel","Astra",100);
        System.out.println("Prędkość: " + auto.speed);
        auto.accelerate(40);
        System.out.println("Prędkość: " + auto.speed);
        auto.decelerate(60);
        System.out.println("Prędkość: " + auto.speed);*/

        //zad 3
/*        BankAccount konto = new BankAccount(400);
        System.out.println("Stan konta: " + konto.balance);
        konto.withdraw(380);
        System.out.println("Stan konta: " + konto.balance);
        konto.deposit(20);
        System.out.println("Stan konta: " + konto.balance);
        konto.withdraw(380);
        System.out.println("Stan konta: " + konto.balance);*/

        //zad 4
/*        Point p1 = new Point(4,0);
        Point p2 = new Point(3,4);
        int odleglosc = p1.distance(p2);
        System.out.println("Odlegość od pi do p2 wynosi: " + odleglosc);*/

        //zad 5
/*        Time czas = new Time(4,34);
        czas.addTime(new Time(6,54));
        System.out.println("Nowy czas to " + czas.hours + ":" + czas.minutes);*/
    }
}