public class Dog {
    String name;
    String breed;
    int age;

    public Dog(String breed, String name, int age) {
        this.breed = breed;
        this.name = name;
        this.age = age;
    }

    public void bark(){
        System.out.println("Wow Wow");
    }
}
