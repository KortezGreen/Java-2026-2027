public class Car {
    String brand;
    String model;
    int speed;

    public Car(String brand, String model, int speed) {
        this.brand = brand;
        this.model = model;
        this.speed = speed;
    }

    public void accelerate(int value){
        speed = speed + value;
    }

    public void decelerate(int value){
        speed = speed - value;
    }
}
