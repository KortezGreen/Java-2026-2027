public class Point {
    int x;
    int y;

    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int distance(Point otherPoint){
        int dx = otherPoint.x - this.x;
        int dy = otherPoint.y - this.y;

        return (int) Math.sqrt(dx * dx + dy * dy);
    }
}
