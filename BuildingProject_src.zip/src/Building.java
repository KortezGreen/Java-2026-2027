public class Building {

    private double height;
    private String color;

    public Building(double height, String color) {
        this.height = height;
        this.color = color;
    }

    public Building() {
        this.height = 10.0;
        this.color = "White";
    }

    public double getHeight() {
        return height;
    }

    public String getColor() {
        return color;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
