public class Main {

    public static void main(String[] args) {

        Building building1 = new Building();
        Building building2 = new Building(15.5, "Blue");

        House house = new House(12.5, "Red", 5);

        System.out.println("Building 1:");
        System.out.println(building1.getHeight());
        System.out.println(building1.getColor());

        System.out.println("Building 2:");
        System.out.println(building2.getHeight());
        System.out.println(building2.getColor());

        System.out.println("House:");
        System.out.println(house.getHeight());
        System.out.println(house.getColor());
        System.out.println(house.getNumberOfRooms());
    }
}
