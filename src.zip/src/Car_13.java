public class Car_13 extends Vehicle_13{
    int numberOfDoors;

    public Car_13(String brand, String model, int yearOfProduction, int numberOfDoors) {
        super(brand, model, yearOfProduction);
        this.numberOfDoors = numberOfDoors;
    }
}
