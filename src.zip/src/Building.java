public class Building{
    double height;
    String color;

    public Building(double height, String color) {
        this.height = height;
        this.color = color;
    }

    public Building() {
        this.height = 444.1;
        this.color = "green";
    }
}
