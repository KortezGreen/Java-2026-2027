void main() {
    //zad 9 dziedziczenie
Car auto = new Car("Opel","Astra",5);
System.out.println("Samochód: " + auto.brand + " " + auto.model + " " + auto.numberOfDoors);

    //zad 10
Dog pies = new Dog();
IO.println(pies.name);

    //zad 11
    House h = new House(844.2, "Red", 5);
    System.out.println(h.height + " " + h.color + " " + h.numberOfRooms);

    //zad 13

}