public class Vehicle_13 {
    String brand;
    String model;
    int yearOfProduction;

    public Vehicle_13(String brand, String model, int yearOfProduction) {
        this.brand = brand;
        this.model = model;
        this.yearOfProduction = yearOfProduction;
    }
}
