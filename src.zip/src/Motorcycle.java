public class Motorcycle extends Vehicle_13{
    double engineCapacity;

    public Motorcycle(String brand, String model, int yearOfProduction, double engineCapacity) {
        super(brand, model, yearOfProduction);
        this.engineCapacity = engineCapacity;
    }

    public double getEngineCapacity() {
        return engineCapacity;
    }

    public void setEngineCapacity(double engineCapacity) {
        this.engineCapacity = engineCapacity;
    }


}
