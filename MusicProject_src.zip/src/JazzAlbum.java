import java.util.ArrayList;
import java.util.Objects;

public class JazzAlbum extends MusicAlbum {

    private String jazzGenre;

    public JazzAlbum(String title, String artist,
                     ArrayList<Integer> ratings, String jazzGenre) {
        super(title, artist, ratings);
        this.jazzGenre = jazzGenre;
    }

    public String getJazzGenre() {
        return jazzGenre;
    }

    public void setJazzGenre(String jazzGenre) {
        this.jazzGenre = jazzGenre;
    }

    @Override
    public String toString() {
        return "JazzAlbum{" +
                "title='" + getTitle() + '\'' +
                ", artist='" + getArtist() + '\'' +
                ", ratings=" + getRatings() +
                ", jazzGenre='" + jazzGenre + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        JazzAlbum that = (JazzAlbum) o;

        return Objects.equals(jazzGenre, that.jazzGenre);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), jazzGenre);
    }
}
