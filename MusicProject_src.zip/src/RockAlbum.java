import java.util.ArrayList;
import java.util.Objects;

public class RockAlbum extends MusicAlbum {

    private String rockGenre;

    public RockAlbum(String title, String artist,
                     ArrayList<Integer> ratings, String rockGenre) {
        super(title, artist, ratings);
        this.rockGenre = rockGenre;
    }

    public String getRockGenre() {
        return rockGenre;
    }

    public void setRockGenre(String rockGenre) {
        this.rockGenre = rockGenre;
    }

    @Override
    public String toString() {
        return "RockAlbum{" +
                "title='" + getTitle() + '\'' +
                ", artist='" + getArtist() + '\'' +
                ", ratings=" + getRatings() +
                ", rockGenre='" + rockGenre + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        RockAlbum that = (RockAlbum) o;

        return Objects.equals(rockGenre, that.rockGenre);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), rockGenre);
    }
}
