import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        ArrayList<Integer> rockRatings = new ArrayList<>();
        rockRatings.add(5);
        rockRatings.add(4);
        rockRatings.add(5);

        ArrayList<Integer> jazzRatings = new ArrayList<>();
        jazzRatings.add(4);
        jazzRatings.add(5);
        jazzRatings.add(3);

        RockAlbum rock = new RockAlbum(
                "Nevermind",
                "Nirvana",
                rockRatings,
                "Grunge"
        );

        JazzAlbum jazz = new JazzAlbum(
                "Kind of Blue",
                "Miles Davis",
                jazzRatings,
                "Cool Jazz"
        );

        System.out.println(rock);
        System.out.println(jazz);

        System.out.println(rock.getTitle());
        System.out.println(rock.getArtist());
        System.out.println(rock.getRockGenre());

        System.out.println(jazz.getTitle());
        System.out.println(jazz.getJazzGenre());

        rock.setTitle("In Utero");
        rock.setRockGenre("Alternative Rock");

        jazz.setJazzGenre("Modal Jazz");

        System.out.println(rock);
        System.out.println(jazz);

        RockAlbum rock2 = new RockAlbum(
                "In Utero",
                "Nirvana",
                rockRatings,
                "Alternative Rock"
        );

        System.out.println(rock.equals(rock2));
        System.out.println(rock.equals(jazz));

        System.out.println(rock.hashCode());
        System.out.println(rock2.hashCode());
        System.out.println(jazz.hashCode());
    }
}
